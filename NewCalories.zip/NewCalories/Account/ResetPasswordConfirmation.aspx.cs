﻿using System.Web.UI;

namespace NewCalories.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}